import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {

  transform(value: Array<string>, args?: any[]): any {
  

    return value.sort((a,b) => 
    {
       if(a<b)
       {
       return -1;
       }
       else{
         return 1;
       }

    }
    );
    return 0;
  }

}
